<?php

/* @FOSUser/Registration/register_content.html.twig */
class __TwigTemplate_92412d33852a1f74d2b379275e32b0bc4ed94b9325932670a2417692dccb0895 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11746d0295497073a075798475f991be85fab158d93ab92217c0a68bb21e8946 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11746d0295497073a075798475f991be85fab158d93ab92217c0a68bb21e8946->enter($__internal_11746d0295497073a075798475f991be85fab158d93ab92217c0a68bb21e8946_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/register_content.html.twig"));

        // line 2
        echo "
<div class=\"container\">
    <div id=\"signupbox\" style=\"margin-top:50px\" class=\"mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2\">
        <div class=\"panel panel-info\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">Sign Up</div>
                <div style=\"float:right; font-size: 85%; position: relative; top:-10px\"><a id=\"signinlink\" href=\"/login\">Sign In</a></div>
            </div>
            <div class=\"panel-body\" >
                ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), 'form_start', array("method" => "post", "action" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register"), "attr" => array("class" => "fos_user_registration_register")));
        echo "

                    <div id=\"signupalert\" style=\"display:none\" class=\"alert alert-danger\">
                        <p>Error:</p>
                        <span></span>
                    </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-user\"></i></span>
                    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 19, $this->getSourceContext()); })()), "username", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Username")));
        echo "
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-envelope\"></i></span>
                    ";
        // line 23
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 23, $this->getSourceContext()); })()), "email", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Email")));
        echo "
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-lock\"></i></span>
                    ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 27, $this->getSourceContext()); })()), "plainPassword", array()), "first", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Password")));
        echo "
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-lock\"></i></span>
                    ";
        // line 31
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 31, $this->getSourceContext()); })()), "plainPassword", array()), "second", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Password Repeat")));
        echo "
                </div>

                    <div class=\"form-group\">
                        <div class=\"col-sm-12 controls\">
                            <button id=\"btn-signup\" type=\"submit\" class=\"btn btn-info\"><i class=\"icon-hand-right\"></i>";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "</button>
                        </div>
                    </div>

                ";
        // line 40
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 40, $this->getSourceContext()); })()), 'form_end');
        echo "
            </div>
        </div>

    </div>
</div>";
        
        $__internal_11746d0295497073a075798475f991be85fab158d93ab92217c0a68bb21e8946->leave($__internal_11746d0295497073a075798475f991be85fab158d93ab92217c0a68bb21e8946_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/register_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 40,  73 => 36,  65 => 31,  58 => 27,  51 => 23,  44 => 19,  33 => 11,  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"container\">
    <div id=\"signupbox\" style=\"margin-top:50px\" class=\"mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2\">
        <div class=\"panel panel-info\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">Sign Up</div>
                <div style=\"float:right; font-size: 85%; position: relative; top:-10px\"><a id=\"signinlink\" href=\"/login\">Sign In</a></div>
            </div>
            <div class=\"panel-body\" >
                {{ form_start(form, {'method': 'post', 'action': path('fos_user_registration_register'), 'attr': {'class': 'fos_user_registration_register'}}) }}

                    <div id=\"signupalert\" style=\"display:none\" class=\"alert alert-danger\">
                        <p>Error:</p>
                        <span></span>
                    </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-user\"></i></span>
                    {{ form_widget(form.username, {'attr': {'class':'form-control','placeholder':'Username'}}) }}
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-envelope\"></i></span>
                    {{ form_widget(form.email, {'attr': {'class':'form-control','placeholder':'Email'}}) }}
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-lock\"></i></span>
                    {{ form_widget(form.plainPassword.first, {'attr': {'class':'form-control','placeholder':'Password'}}) }}
                </div>
                <div style=\"margin-bottom: 25px\" class=\"input-group\">
                    <span class=\"input-group-addon\"><i class=\"glyphicon glyphicon-lock\"></i></span>
                    {{ form_widget(form.plainPassword.second, {'attr': {'class':'form-control','placeholder':'Password Repeat'}}) }}
                </div>

                    <div class=\"form-group\">
                        <div class=\"col-sm-12 controls\">
                            <button id=\"btn-signup\" type=\"submit\" class=\"btn btn-info\"><i class=\"icon-hand-right\"></i>{{ 'registration.submit'|trans }}</button>
                        </div>
                    </div>

                {{ form_end(form) }}
            </div>
        </div>

    </div>
</div>", "@FOSUser/Registration/register_content.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/Registration/register_content.html.twig");
    }
}
