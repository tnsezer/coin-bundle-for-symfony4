<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_459041e244d39bfeff2fb20d310ff41fa39f9391424175648a1e090c5c570502 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05de973ff3b2280c187352d547ecd6b181825a8a76775861a8d7325ab78940db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05de973ff3b2280c187352d547ecd6b181825a8a76775861a8d7325ab78940db->enter($__internal_05de973ff3b2280c187352d547ecd6b181825a8a76775861a8d7325ab78940db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_05de973ff3b2280c187352d547ecd6b181825a8a76775861a8d7325ab78940db->leave($__internal_05de973ff3b2280c187352d547ecd6b181825a8a76775861a8d7325ab78940db_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_94b59b64d10807765e2511d712e1d25addebc571578cf13687afba64ea48214b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94b59b64d10807765e2511d712e1d25addebc571578cf13687afba64ea48214b->enter($__internal_94b59b64d10807765e2511d712e1d25addebc571578cf13687afba64ea48214b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    ";
        $this->loadTemplate("@FOSUser/Security/login_content.html.twig", "@FOSUser/Security/login.html.twig", 4)->display($context);
        
        $__internal_94b59b64d10807765e2511d712e1d25addebc571578cf13687afba64ea48214b->leave($__internal_94b59b64d10807765e2511d712e1d25addebc571578cf13687afba64ea48214b_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
    {% include \"@FOSUser/Security/login_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Security/login.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/Security/login.html.twig");
    }
}
