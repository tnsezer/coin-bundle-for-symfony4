<?php

/* @FOSUser/Profile/show.html.twig */
class __TwigTemplate_3b71ce0d84ffc9bda2aa2f4a5a0162cc552e99a542bc706201defddb37a0eb4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Profile/show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_635527c09eaa2aa5bc0e2360be7ac62c5e802f599eae54971d3903347a936601 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_635527c09eaa2aa5bc0e2360be7ac62c5e802f599eae54971d3903347a936601->enter($__internal_635527c09eaa2aa5bc0e2360be7ac62c5e802f599eae54971d3903347a936601_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Profile/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_635527c09eaa2aa5bc0e2360be7ac62c5e802f599eae54971d3903347a936601->leave($__internal_635527c09eaa2aa5bc0e2360be7ac62c5e802f599eae54971d3903347a936601_prof);

    }

    // line 4
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ae89e7152e59e5309cc057433ff2ff8c451527c77fbfb6e1a46cec3ca1cd0949 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae89e7152e59e5309cc057433ff2ff8c451527c77fbfb6e1a46cec3ca1cd0949->enter($__internal_ae89e7152e59e5309cc057433ff2ff8c451527c77fbfb6e1a46cec3ca1cd0949_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 5
        $this->loadTemplate("@FOSUser/Profile/show_content.html.twig", "@FOSUser/Profile/show.html.twig", 5)->display($context);
        
        $__internal_ae89e7152e59e5309cc057433ff2ff8c451527c77fbfb6e1a46cec3ca1cd0949->leave($__internal_ae89e7152e59e5309cc057433ff2ff8c451527c77fbfb6e1a46cec3ca1cd0949_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  34 => 4,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}


{% block fos_user_content %}
{% include \"@FOSUser/Profile/show_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Profile/show.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/Profile/show.html.twig");
    }
}
