<?php

/* @FOSUser/Profile/show_content.html.twig */
class __TwigTemplate_889b493636cd24e62504b1c7cc5d86ab2d47b7889dd88df6b22d5cebe5cabb21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_021cdc7e31eb79ee38015a9ebba00c88155558b627355ff0a8b97d5dffac0829 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_021cdc7e31eb79ee38015a9ebba00c88155558b627355ff0a8b97d5dffac0829->enter($__internal_021cdc7e31eb79ee38015a9ebba00c88155558b627355ff0a8b97d5dffac0829_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Profile/show_content.html.twig"));

        // line 2
        echo "
<div class=\"col-sm-9 offset-sm-3 col-md-10 offset-md-2 pt-3\">
    <div class=\"table-responsive\">
        <table class=\"table table-striped\">
            <tbody>
            <tr>
                <td>";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</td>
                <td>";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 9, $this->getSourceContext()); })()), "username", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <td>";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo "</td>
                <td>";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 13, $this->getSourceContext()); })()), "email", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <td>";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("profile.show.coin", array(), "FOSUserBundle"), "html", null, true);
        echo "</td>
                <td>";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new Twig_Error_Runtime('Variable "user" does not exist.', 17, $this->getSourceContext()); })()), "coin", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <td><input type=\"button\" id=\"buy\" value=\"Buy\" class=\"btn btn-info\" /></td>
                <td><input type=\"text\" id=\"buyInput\" class=\"form-control\" /></td>
            </tr>
            <tr>
                <td><input type=\"button\" id=\"check\" value=\"Check\" class=\"btn btn-info\" /></td>
                <td><input type=\"text\" id=\"checkInput\" class=\"form-control\" /></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>";
        
        $__internal_021cdc7e31eb79ee38015a9ebba00c88155558b627355ff0a8b97d5dffac0829->leave($__internal_021cdc7e31eb79ee38015a9ebba00c88155558b627355ff0a8b97d5dffac0829_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 17,  50 => 16,  44 => 13,  40 => 12,  34 => 9,  30 => 8,  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}

<div class=\"col-sm-9 offset-sm-3 col-md-10 offset-md-2 pt-3\">
    <div class=\"table-responsive\">
        <table class=\"table table-striped\">
            <tbody>
            <tr>
                <td>{{ 'profile.show.username'|trans }}</td>
                <td>{{ user.username }}</td>
            </tr>
            <tr>
                <td>{{ 'profile.show.email'|trans }}</td>
                <td>{{ user.email }}</td>
            </tr>
            <tr>
                <td>{{ 'profile.show.coin'|trans }}</td>
                <td>{{ user.coin }}</td>
            </tr>
            <tr>
                <td><input type=\"button\" id=\"buy\" value=\"Buy\" class=\"btn btn-info\" /></td>
                <td><input type=\"text\" id=\"buyInput\" class=\"form-control\" /></td>
            </tr>
            <tr>
                <td><input type=\"button\" id=\"check\" value=\"Check\" class=\"btn btn-info\" /></td>
                <td><input type=\"text\" id=\"checkInput\" class=\"form-control\" /></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>", "@FOSUser/Profile/show_content.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/Profile/show_content.html.twig");
    }
}
