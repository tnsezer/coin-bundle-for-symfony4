<?php

/* base.html.twig */
class __TwigTemplate_0ca1fc36819d5fe74dd1990f6a178534342e6198588378a5072937eada72def1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9869960d4f11bc44c84d4af698189b8069c36589940418acd8e9bcb439f61d3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9869960d4f11bc44c84d4af698189b8069c36589940418acd8e9bcb439f61d3a->enter($__internal_9869960d4f11bc44c84d4af698189b8069c36589940418acd8e9bcb439f61d3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link href=\"//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
        <script src=\"//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js\"></script>
        <script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>

        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "    </head>
    <body>
        ";
        // line 15
        $this->displayBlock('body', $context, $blocks);
        // line 16
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 17
        echo "    </body>
</html>
";
        
        $__internal_9869960d4f11bc44c84d4af698189b8069c36589940418acd8e9bcb439f61d3a->leave($__internal_9869960d4f11bc44c84d4af698189b8069c36589940418acd8e9bcb439f61d3a_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_84e332f8dee885234773ee38fda21276a0d764ed3254cc6b3a19fe2b50b973e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84e332f8dee885234773ee38fda21276a0d764ed3254cc6b3a19fe2b50b973e0->enter($__internal_84e332f8dee885234773ee38fda21276a0d764ed3254cc6b3a19fe2b50b973e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_84e332f8dee885234773ee38fda21276a0d764ed3254cc6b3a19fe2b50b973e0->leave($__internal_84e332f8dee885234773ee38fda21276a0d764ed3254cc6b3a19fe2b50b973e0_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f8cfa18a0884ea260b91da89aa1351316c6deaa660eaed40b078b008725c4ecb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8cfa18a0884ea260b91da89aa1351316c6deaa660eaed40b078b008725c4ecb->enter($__internal_f8cfa18a0884ea260b91da89aa1351316c6deaa660eaed40b078b008725c4ecb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_f8cfa18a0884ea260b91da89aa1351316c6deaa660eaed40b078b008725c4ecb->leave($__internal_f8cfa18a0884ea260b91da89aa1351316c6deaa660eaed40b078b008725c4ecb_prof);

    }

    // line 15
    public function block_body($context, array $blocks = array())
    {
        $__internal_91283e329eb5b31714b1ca37d5ee6cef9b3d0c06ce84dc77dc19493284cb40a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91283e329eb5b31714b1ca37d5ee6cef9b3d0c06ce84dc77dc19493284cb40a3->enter($__internal_91283e329eb5b31714b1ca37d5ee6cef9b3d0c06ce84dc77dc19493284cb40a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_91283e329eb5b31714b1ca37d5ee6cef9b3d0c06ce84dc77dc19493284cb40a3->leave($__internal_91283e329eb5b31714b1ca37d5ee6cef9b3d0c06ce84dc77dc19493284cb40a3_prof);

    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_82a3e25283ef09a1d9647a8c0e0033e0a6db45d00db2798c973ed91d69986538 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82a3e25283ef09a1d9647a8c0e0033e0a6db45d00db2798c973ed91d69986538->enter($__internal_82a3e25283ef09a1d9647a8c0e0033e0a6db45d00db2798c973ed91d69986538_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_82a3e25283ef09a1d9647a8c0e0033e0a6db45d00db2798c973ed91d69986538->leave($__internal_82a3e25283ef09a1d9647a8c0e0033e0a6db45d00db2798c973ed91d69986538_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  96 => 16,  85 => 15,  74 => 12,  62 => 6,  53 => 17,  50 => 16,  48 => 15,  44 => 13,  42 => 12,  33 => 6,  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>{% block title %}Welcome!{% endblock %}</title>

        <link href=\"//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
        <script src=\"//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js\"></script>
        <script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>

        {% block stylesheets %}{% endblock %}
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/home/symfony/templates/base.html.twig");
    }
}
