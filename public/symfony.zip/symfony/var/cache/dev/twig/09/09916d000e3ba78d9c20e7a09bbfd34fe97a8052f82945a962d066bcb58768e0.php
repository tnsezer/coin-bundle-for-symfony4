<?php

/* @FOSUser/Registration/register.html.twig */
class __TwigTemplate_2f69517b3eb456177f8ff1eccd47d37aab4a61e60786b41fa36b3552e6046a21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@FOSUser/layout.html.twig", "@FOSUser/Registration/register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@FOSUser/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fa363c046c323bd636c53c86c49608327e3d0019440f613f05bb0197083f0d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fa363c046c323bd636c53c86c49608327e3d0019440f613f05bb0197083f0d5->enter($__internal_4fa363c046c323bd636c53c86c49608327e3d0019440f613f05bb0197083f0d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4fa363c046c323bd636c53c86c49608327e3d0019440f613f05bb0197083f0d5->leave($__internal_4fa363c046c323bd636c53c86c49608327e3d0019440f613f05bb0197083f0d5_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a5db5412a57c4a85e9e0e3dae734c674552862c3305a820e2005f8b65ef878a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5db5412a57c4a85e9e0e3dae734c674552862c3305a820e2005f8b65ef878a9->enter($__internal_a5db5412a57c4a85e9e0e3dae734c674552862c3305a820e2005f8b65ef878a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("@FOSUser/Registration/register_content.html.twig", "@FOSUser/Registration/register.html.twig", 4)->display($context);
        
        $__internal_a5db5412a57c4a85e9e0e3dae734c674552862c3305a820e2005f8b65ef878a9->leave($__internal_a5db5412a57c4a85e9e0e3dae734c674552862c3305a820e2005f8b65ef878a9_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@FOSUser/layout.html.twig\" %}

{% block fos_user_content %}
{% include \"@FOSUser/Registration/register_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Registration/register.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/Registration/register.html.twig");
    }
}
