<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_b14d91a5efa886f87ddb0d7a54329266fa701b0ffb6afbfef2fc67fa6d1c0deb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74731963f8948faaa8ed3363e9236c955498d7eaff914887dddae7ba5eb6ebd4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74731963f8948faaa8ed3363e9236c955498d7eaff914887dddae7ba5eb6ebd4->enter($__internal_74731963f8948faaa8ed3363e9236c955498d7eaff914887dddae7ba5eb6ebd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link href=\"/css/app.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
        <script type=\"text/javascript\" src=\"/scripts/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/bootstrap.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/jwt-decode.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/app.js\"></script>
    </head>
    <body>
        <div>
            ";
        // line 16
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 17
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 17, $this->getSourceContext()); })()), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 18
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
            ";
        } else {
            // line 22
            echo "
            ";
        }
        // line 24
        echo "        </div>

        ";
        // line 26
        if (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 26, $this->getSourceContext()); })()), "request", array()), "hasPreviousSession", array())) {
            // line 27
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 27, $this->getSourceContext()); })()), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 28
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 29
                    echo "                    <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                        ";
                    // line 30
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                    </div>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 33
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 34
            echo "        ";
        }
        // line 35
        echo "        <div>
            ";
        // line 36
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 38
        echo "        </div>
    </body>
</html>
";
        
        $__internal_74731963f8948faaa8ed3363e9236c955498d7eaff914887dddae7ba5eb6ebd4->leave($__internal_74731963f8948faaa8ed3363e9236c955498d7eaff914887dddae7ba5eb6ebd4_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_3b10c3b8bfd4ed9f52262f6fd8da013befce7486b629f5a9e8b4bf662de1c4c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b10c3b8bfd4ed9f52262f6fd8da013befce7486b629f5a9e8b4bf662de1c4c2->enter($__internal_3b10c3b8bfd4ed9f52262f6fd8da013befce7486b629f5a9e8b4bf662de1c4c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_3b10c3b8bfd4ed9f52262f6fd8da013befce7486b629f5a9e8b4bf662de1c4c2->leave($__internal_3b10c3b8bfd4ed9f52262f6fd8da013befce7486b629f5a9e8b4bf662de1c4c2_prof);

    }

    // line 36
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_22e965f100c9e10ea096c7aae813073f0fceaa65f0bc3d8957429a2db1805253 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22e965f100c9e10ea096c7aae813073f0fceaa65f0bc3d8957429a2db1805253->enter($__internal_22e965f100c9e10ea096c7aae813073f0fceaa65f0bc3d8957429a2db1805253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 37
        echo "            ";
        
        $__internal_22e965f100c9e10ea096c7aae813073f0fceaa65f0bc3d8957429a2db1805253->leave($__internal_22e965f100c9e10ea096c7aae813073f0fceaa65f0bc3d8957429a2db1805253_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 37,  131 => 36,  119 => 6,  109 => 38,  107 => 36,  104 => 35,  101 => 34,  95 => 33,  86 => 30,  81 => 29,  76 => 28,  71 => 27,  69 => 26,  65 => 24,  61 => 22,  55 => 19,  51 => 18,  46 => 17,  44 => 16,  31 => 6,  24 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>{% block title %}Welcome!{% endblock %}</title>

        <link href=\"/css/app.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
        <script type=\"text/javascript\" src=\"/scripts/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/bootstrap.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/jwt-decode.min.js\"></script>
        <script type=\"text/javascript\" src=\"/scripts/app.js\"></script>
    </head>
    <body>
        <div>
            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}
                </a>
            {% else %}

            {% endif %}
        </div>

        {% if app.request.hasPreviousSession %}
            {% for type, messages in app.session.flashbag.all() %}
                {% for message in messages %}
                    <div class=\"flash-{{ type }}\">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endfor %}
        {% endif %}
        <div>
            {% block fos_user_content %}
            {% endblock fos_user_content %}
        </div>
    </body>
</html>
", "@FOSUser/layout.html.twig", "/home/symfony/templates/bundles/FOSUserBundle/layout.html.twig");
    }
}
